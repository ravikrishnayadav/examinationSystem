<html>
    <style>
            .container {
    width: 80%;
    margin: 0 auto;
    }

    footer {
    background-color: #154360;
    color: #fff;
    text-align: center;
    padding: 10px 0;
    margin-bottom:10px;
    }
    </style>

    <footer>
        <div class="container">
            <p>&copy; 2024 KSRM COLLEGE OF ENGINEERING. All rights reserved.</p>
        </div>
    </footer>
</html>