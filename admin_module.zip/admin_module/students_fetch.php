<?php
session_start();
if(!isset($_SESSION['loggedin']))
{
    header("Location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdn.datatables.net/2.0.0/css/dataTables.dataTables.min.css">
    
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
  <title>Database Table</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            overflow-x: auto; /* Add horizontal scroll for small screens */
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            white-space: nowrap; /* Prevent line breaks */
        }
        th {
            background-color: #f2f2f2;
        }
        img {
            max-width: 100px;
            max-height: 100px;
        }
        /* Responsive styles */
        @media only screen and (max-width: 600px) {
            table {
                overflow-x: auto; /* Add horizontal scroll for small screens */
            }
        }
    </style>
</head>
<body>
    <?php include 'header1.php'; ?>
    
    <!-- Step 1: Connect to your database -->
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "lokesh";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Step 2: Execute a query to fetch the desired data
 
    ?>
    <!-- Step 4: Output the HTML table -->
    <div style="overflow-x: auto;">
    <table class="table" id="myTable">
  <thead>
    <tr>
      <th scope="col">reg_id</th>
      <th scope="col">reg_no</th>
      <th scope="col">name</th>
      <th scope="col">fname</th>
      <th scope="col">inter</th>
      <th scope="col">gender</th>
      <th scope="col">dob</th>
      
      <th scope="col">district</th>
      <th scope="col">category</th>
      <th scope="col">photo</th>
      <th scope="col">signature</th>
      <th scope="col">email</th>
      <th scope="col">phone</th>
      
   
    </tr>
  </thead>
  <tbody>
    
    <?php
      $sql = "SELECT * FROM registrations";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                  echo "<tr>";
                    echo "<td>" . $row["reg_id"] . "</td>";
                    echo "<td>" . $row["reg_no"] . "</td>";
                    echo "<td>" . $row["name"] . "</td>";
                    echo "<td>" . $row["fname"] . "</td>";
                    echo "<td>" . $row["intermediate_hallticket"] . "</td>";
                    echo "<td>" . $row["gender"] . "</td>";
                    echo "<td>" . $row["dob"] . "</td>";
                    echo "<td>" . $row["address"] . "</td>";
                    echo "<td>" . $row["category"] . "</td>";
                    echo "<td><img src='uploads/" . $row["image"] . "' alt='Image'></td>";
                    echo "<td><img src='uploads/" . $row["sign"] . "' alt='Signature'></td>";
                    echo "<td>" . $row["email"] . "</td>";
                    echo "<td>" . $row["mobile"] . "</td>"; // Display mobile number
                    echo "</tr>";
                   
                }
              }
                ?>
      
    
  </tbody>
</table>
    </div>
    <div style="text-align: center; margin-top: 20px;">
    <div style="display: inline-block; margin-right: 10px;">
        <form action="download_data.php" method="post" style="display: inline;">
            <button type="submit" class="btn btn-primary">Download Pdf</button>
        </form>
    </div>
    <div style="display: inline-block;">
        <form action="export_to_excel.php" method="post" style="display: inline;">
            <button type="submit" class="btn btn-success">Export to Excel</button>
        </form>
    </div>
</div>


    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<script src="//cdn.datatables.net/2.0.0/js/dataTables.min.js"></script>
    <script>
      let table = new DataTable('#myTable');
    </script>
   
</body>
</html>
