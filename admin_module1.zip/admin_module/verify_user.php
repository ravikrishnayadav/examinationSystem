<?php
// Replace these with your actual database credentials
$servername = "localhost";
$username = "root";
$password = "";
$database = "lokesh";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $enteredUsername = $_POST["username"];
    $enteredPassword = $_POST["password"];

    // Query to retrieve user from the database
    $sql = "SELECT * FROM admin_password WHERE username = '$enteredUsername' AND password = '$enteredPassword'";
    $result = $conn->query($sql);

    // Check if the query returned any rows (user found)
    if ($result->num_rows > 0) {
        // Fetch user data
        $userData = $result->fetch_assoc();
         $_SESSION['user_id'] = $userData['id'];
        $_SESSION['username'] = $userData['username'];

        // Redirect to admin_interface.php
        header("Location: admin_home.php");
        exit();
    } else {
        echo "Invalid username or password.";
    }    
       
}

// Close connection
$conn->close();
?>
